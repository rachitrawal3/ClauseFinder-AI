import os
import json
import re
import csv
import tempfile
from datetime import datetime
from tools import (
    get_llm,
    get_embeddings,
    build_clause_context,
    safe_parse_clauses,
    extract_clauses_fallback,
    save_to_csv,
)
import streamlit as st
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

# Core RAG pipeline for a single uploaded PDF
def analyze_contract(uploaded_file):
    # 1) Save uploaded file to a temp path so PyPDFLoader can read it
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(uploaded_file.getbuffer())
        tmp_path = tmp.name

    # 2) Load PDF as Documents
    loader = PyPDFLoader(tmp_path)
    docs = loader.load()  # list[Document], usually per page

    # 3) Split documents into smaller chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
    )
    split_docs = text_splitter.split_documents(docs)

    # 4) Build vectorstore with sentence-transformers embeddings + FAISS
    embeddings = get_embeddings()
    vectorstore = FAISS.from_documents(split_docs, embeddings)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 6})

    llm = get_llm()

    
    # 5) LLM Call #1: Clause Extraction (RAG style, with stronger context)
    
    clause_context = build_clause_context(split_docs, retriever)

    clause_prompt = f"""
You are a legal AI assistant.

Your ONLY job is to locate and COPY the following clauses from the contract text
in CONTEXT below:

1. Termination conditions
2. Confidentiality clause
3. Liability clause

Important instructions:
- Copy the relevant sentences/paragraphs VERBATIM from the context.
- Prefer clauses whose headings explicitly contain words like
  "Term", "Termination", "Confidential", "Confidentiality",
  "Confidential Information", "Liability", or "Limitation of Liability".
- Do NOT explain, summarize, or judge relevance.
- If a clause truly cannot be found in the CONTEXT, set that field to null
  (the JSON literal null). Do NOT claim in words that it does not exist.

Return ONLY valid JSON with exactly these keys:
{{
  "termination_clause": "... or null",
  "confidentiality_clause": "... or null",
  "liability_clause": "... or null"
}}

CONTEXT:
{clause_context}
""".strip()

    clause_raw = llm.invoke(clause_prompt).content.strip()
    clauses = safe_parse_clauses(clause_raw)

    # normalize null -> "N/A" later, but keep raw here
    termination_clause = clauses.get("termination_clause") or ""
    confidentiality_clause = clauses.get("confidentiality_clause") or ""
    liability_clause = clauses.get("liability_clause") or ""

    
    # 6) LLM Call #2: Contract Summary (RAG style, but no "no clause" claims)
    
    summary_docs = retriever.get_relevant_documents(
        "overall purpose of the agreement, obligations, termination, confidentiality, liability, risks"
    )
    summary_context = "\n\n".join(d.page_content for d in summary_docs)

    summary_prompt = f"""
You are a legal AI assistant.

Using ONLY the CONTEXT and CLAUSES below, write a clear,
concise summary of this contract in 100–150 words.

The summary must cover:
- Purpose of the agreement
- Key obligations of each party
- Notable risks or penalties (especially around termination, confidentiality, liability)

CRITICAL RULE:
- You must NOT claim that any type of clause (e.g., confidentiality or liability)
  is "missing", "not present", or "not specified". If you are unsure, simply do
  not comment on the presence/absence of that clause.

CONTEXT:
{summary_context}

EXTRACTED CLAUSES:
- Termination: {termination_clause or "N/A"}
- Confidentiality: {confidentiality_clause or "N/A"}
- Liability: {liability_clause or "N/A"}

Write the summary in plain English, suitable for a non-lawyer.
Do not use bullet points or numbered lists. Use 1–2 short paragraphs.
""".strip()

    summary = llm.invoke(summary_prompt).content.strip()

    return {
        "summary": summary,
        "termination_clause": termination_clause,
        "confidentiality_clause": confidentiality_clause,
        "liability_clause": liability_clause,
        "raw_clause_response": clause_raw,  # optional: for debugging
    }


