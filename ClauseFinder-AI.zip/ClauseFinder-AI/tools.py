import os
import json
import re
import csv
import tempfile
from datetime import datetime

import streamlit as st
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

# Setup

load_dotenv()
groq_api_key = os.getenv("GROQ_API_KEY")

st.set_page_config(page_title="Contract Analyzer", page_icon="📄")

st.title("📄 Contract Analyzer (RAG + Groq + FAISS)")
st.write(
    "Upload a contract PDF and I'll extract key clauses "
    "(Termination, Confidentiality, Liability) and generate a concise summary."
)


# Cached resources (embeddings + LLM)

@st.cache_resource(show_spinner="Loading embeddings model...")
def get_embeddings():
    # sentence-transformers model
    return HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

@st.cache_resource(show_spinner="Initializing Groq LLM...")
def get_llm():
    return ChatGroq(
        groq_api_key=groq_api_key,
        model_name="meta-llama/llama-4-maverick-17b-128e-instruct",
        temperature=0
    )

# Helpers: robust clause parsing
def extract_clauses_fallback(text: str):
    """
    When JSON parsing fails, try to pull out labelled clauses like:
    Termination Clause: "...."
    Confidentiality Clause: "...."
    Liability Clause: "...."
    """

    def grab(label: str) -> str:
        # non-greedy until next label or end
        pattern = rf"{label}\s*:\s*(.*?)(?=\n\s*Termination Clause:|\n\s*Confidentiality Clause:|\n\s*Liability Clause:|\Z)"
        m = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
        if not m:
            return ""
        val = m.group(1).strip()
        # strip wrapping quotes if present
        if val.startswith('"') and val.endswith('"'):
            val = val[1:-1].strip()
        return val

    return {
        "termination_clause": grab("Termination Clause"),
        "confidentiality_clause": grab("Confidentiality Clause"),
        "liability_clause": grab("Liability Clause"),
    }

def safe_parse_clauses(text: str):
    cleaned = text.strip()

    # strip ```json fences if model used them
    cleaned = cleaned.replace("```json", "").replace("```", "").strip()

    # 1) try JSON
    try:
        data = json.loads(cleaned)
        for k in ["termination_clause", "confidentiality_clause", "liability_clause"]:
            data.setdefault(k, "")
        return data
    except Exception:
        # 2) fallback regex over labelled text
        clauses = extract_clauses_fallback(cleaned)
        # if everything is empty, last resort: put whole text into termination_clause
        if not any(clauses.values()):
            return {
                "termination_clause": cleaned,
                "confidentiality_clause": "",
                "liability_clause": "",
            }
        return clauses

def build_clause_context(split_docs, retriever):
    """
    Build a strong context that almost surely contains
    confidentiality + liability + termination clauses.

    Mix of:
      - keyword-filtered chunks
      - retriever top-k chunks
    """

    keyword_docs = []
    for d in split_docs:
        txt = d.page_content.lower()
        if any(
            kw in txt
            for kw in [
                "confidential",
                "non-disparagement",
                "liability",
                "limitation of liability",
                "terminate",
                "termination",
                "post-term sales",
            ]
        ):
            keyword_docs.append(d)

    retrieved = retriever.get_relevant_documents(
        "termination conditions, confidentiality, and liability clauses in this contract"
    )

    # dedupe by (page_content, page number) combo
    seen = set()
    all_docs = []
    for d in keyword_docs + retrieved:
        key = (d.page_content, d.metadata.get("page", None))
        if key not in seen:
            seen.add(key)
            all_docs.append(d)

    return "\n\n".join(d.page_content for d in all_docs)

def save_to_csv(contract_id, summary, termination_clause, confidentiality_clause, liability_clause):
    """
    Appends the analysis results to a CSV file.
    Creates the file with headers if it doesn't exist.
    """
    file_name = "contracts_analysis.csv"
    file_exists = os.path.isfile(file_name)

    # Define the column names
    fieldnames = [
        'contract_id', 
        'summary', 
        'termination_clause', 
        'confidentiality_clause', 
        'liability_clause',
        'timestamp'
    ]

    try:
        with open(file_name, mode='a', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            # Write header only if the file is new
            if not file_exists:
                writer.writeheader()

            # Write the data row
            writer.writerow({
                'contract_id': contract_id,
                'summary': summary,
                'termination_clause': termination_clause,
                'confidentiality_clause': confidentiality_clause,
                'liability_clause': liability_clause,
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
        return True
    except Exception as e:
        st.error(f"Error saving to CSV: {e}")
        return False

