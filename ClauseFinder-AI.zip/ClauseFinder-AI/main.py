import os
import json
import re
import csv
import tempfile
from datetime import datetime
from tools import (
    get_llm,
    get_embeddings,
    build_clause_context,
    safe_parse_clauses,
    extract_clauses_fallback,
    save_to_csv,
)
from pipeline import analyze_contract
import streamlit as st
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings



# Streamlit UI

uploaded_pdf = st.file_uploader(
    "Upload a contract PDF",
    type=["pdf"],
    help="Upload a single contract PDF file to analyze.",
)

analyze_button = st.button("Analyze Contract", type="primary", disabled=uploaded_pdf is None)

if analyze_button and uploaded_pdf is not None:
    with st.spinner("Analyzing contract with RAG pipeline..."):
        result = analyze_contract(uploaded_pdf)

    st.subheader("📌 Contract Summary (100–150 words)")
    st.write(result["summary"])

    st.subheader("📜 Termination Clause")
    st.write(result["termination_clause"] or "_Not found_")

    st.subheader("📜 Confidentiality Clause")
    st.write(result["confidentiality_clause"] or "_Not found_")

    st.subheader("📜 Liability Clause")
    st.write(result["liability_clause"] or "_Not found_")

    # Optional: show raw model output to debug / validate
    with st.expander("🔍 Raw clause extraction output (debug)"):
        st.code(result["raw_clause_response"], language="json")
    
    # Save results to CSV
    contract_id = uploaded_pdf.name  # Use filename as ID
    
    save_success = save_to_csv(
        contract_id=contract_id,
        summary=result["summary"],
        termination_clause=result["termination_clause"],
        confidentiality_clause=result["confidentiality_clause"],
        liability_clause=result["liability_clause"]
    )

    if save_success:
        st.success(f"✅ Analysis appended to `contracts_analysis.csv` (ID: {contract_id})")
